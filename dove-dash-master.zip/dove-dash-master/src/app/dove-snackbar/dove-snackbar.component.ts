import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-dove-snackbar",
  templateUrl: "./dove-snackbar.component.html",
  styleUrls: ["./dove-snackbar.component.scss"]
})
export class DoveSnackbarComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
